# Evidence geometry and behavioral control in GoalZendo

## Status and question

This is a prospective, adaptively motivated mechanism study. Its question was
chosen after inspecting the completed contemporary-model results, but none of
these 36 runs has been launched or observed. Its conditions, seeds, endpoints,
and analysis are fixed before those outcomes exist. The earlier
evidence-geometry protocol remains archived as an unrun design and is
superseded rather than amended by this document.

The completed contemporary-model study found that parity-Law outcome-RL
policies could attain high ordinary training-distribution accuracy while
remaining controlled by the Herald at a Herald accuracy of .95. That result
leaves open why five per cent counterexamples failed to establish behavioral
control by the Official Law. The follow-up asks whether the answer depends on
the *geometry* of the evidence: whether Herald and Sage failures coincide, and
whether diagnostic conflicts cover many distinct scenes or repeatedly present
a small support.

This distinction matters for predicting behavior after deployment. Two
training sets can encode the same reward criterion and the same marginal
shortcut accuracies while differing in whether their counterexamples
jointly distinguish the intended behavior from several alternatives. If that
structure changes conflict behavior, aggregate training accuracy and total
counterexample count are insufficient for predicting how a trained system
will act when its correlates separate. GoalZendo makes this question
identifiable by independently evaluating agreement with the Official Law
\(Y\), Herald \(P\), and Sage \(Q\). These measurements identify behavioral
control under the tested interventions; they do not identify a model's
internal objective, motivation, or representation.

## Fixed comparison

Every run uses the parity Official Law under outcome RL, with
\(q_P=.95\), \(q_Q=.90\), 10,000 training examples, and 1,000 IID validation
examples. The three evidence conditions are:

1. **Product-overlap, diverse:** joint Herald--Sage error rate .005, equal to
   the product of the two marginal error rates, with a distinct semantic scene
   for every training presentation.
2. **Joint-rich, diverse:** joint error rate .04, with a distinct semantic
   scene for every training presentation.
3. **Joint-rich, concentrated:** joint error rate .04, with exactly 16 unique
   training decisions in each of the six absolute conflict tuples
   \((Y,P,Q)\), repeated deterministically within its tuple. The two agreement
   tuples remain diverse.

The first comparison changes error overlap while holding diversity fixed. The
second changes conflict diversity while holding the .04 overlap fixed. The
three-cell design does not estimate an overlap-by-diversity interaction and no
such claim will be made.

At 10,000 examples, all three conditions have exactly 500 Herald errors and 1,000
Sage errors. The product-overlap condition contains 50 joint errors. Its
absolute candidate-tuple counts are 4,275 in each agreement tuple, 475 in each
Sage-only error tuple, 225 in each Herald-only error tuple, and 25 in each
joint-error tuple. The joint-rich conditions contain 400 joint errors, giving
4,450, 300, 50, and 200 examples per corresponding absolute tuple. These
counts, the generated banks, and their ordered digests are determined from the
configuration and seed before model training. Evaluation and intervention
scenes are semantically disjoint from training and from one another except
for their registered mirror or intervention relations.

## Models, pairing, and training

The immutable model targets are:

| Model | Hugging Face revision |
|---|---|
| `Qwen/Qwen3.5-0.8B` | `2fc06364715b967f1860aea9cf38778875588b17` |
| `Qwen/Qwen3.5-2B` | `15852e8c16360a2fea060d615a32b45270f8a8fc` |

Both sizes are crossed with all three evidence conditions and six fresh paired
training seeds:

`22011, 22013, 22017, 22019, 22023, 22031`.

The resulting \(2\times3\times6\) design contains exactly 36 runs. A seed is
paired across model size and evidence condition. None appeared in the
contemporary-model pilot or main panel.

Training reproduces the verified outcome-RL settings: full-model BF16 updates,
learning rate \(3\times10^{-6}\), entropy coefficient .01, zero KL
coefficient, four samples per prompt, micro-batch 10, five-way gradient
accumulation, gradient checkpointing, and a 768-token ceiling. Each run
receives 1,000 updates and is evaluated at updates 0, 1, 4, 16, 64, 256, 512,
and 1,000. Recovery checkpoints are written at 512 and 1,000; model snapshots
are not retained. The diagnostic factorial and causal panels contain 16 and 8
examples per cell, and the final panels contain 64 and 16. The ordinary
`full` and matched-layout Law-audit views are recorded, while causal
interventions target the ordinary view.

There is no pilot, qualification gate, or result-contingent branch. No
learning-rate search, entropy search, prompt change, additional condition,
training extension, seed replacement, or failed-run substitution is part of
the study. A mechanically interrupted run may resume from its registered
checkpoint without changing its identity. Any scientifically complete run is
retained regardless of its result.

## Endpoints and analysis

For a candidate source \(g\in\{Y,P,Q\}\), let

\[
\rho_g=\Pr(\hat a=g\mid Y,P,Q\text{ do not all agree})
\]

on the six disagreement cells of the final balanced `full` factorial panel.
The complete eight-cell truth table is retained to detect conditional
policies. The primary contrast is the paired overlap effect on Official-Law
agreement,

\[
\Delta_{\mathrm{overlap}}^{\rho}
=\rho_Y(\text{joint-rich, diverse})
-\rho_Y(\text{product-overlap, diverse}).
\]

Its causal companion first measures the relative intervention control within
each run,

\[
C_Y=\operatorname{flip}_Y-
\tfrac12(\operatorname{flip}_P+\operatorname{flip}_Q),
\]

then takes the same paired joint-rich-minus-product-overlap contrast in
\(C_Y\). Positive values mean that changing the Official Law changes actions
more often, relative to changing the two competing sources.

The secondary diversity contrast is

\[
\Delta_{\mathrm{diversity}}^{\rho}
=\rho_Y(\text{joint-rich, diverse})
-\rho_Y(\text{joint-rich, concentrated}),
\]

with the corresponding diverse-minus-concentrated contrast in \(C_Y\) as its
causal companion. Final \(\rho_P\), \(\rho_Q\), IID Official-Law accuracy,
matched-layout Law agreement, and registered checkpoint trajectories are
reported descriptively so that a change in control can be distinguished from
a general capability loss.

The training seed is the inferential unit. Each contrast is reported
separately for the two model sizes and as a seed-blocked summary that averages
the two size-specific paired differences within each seed. The report includes
all six seed-level values, their mean, the deterministic 95% percentile
interval over all \(6^6=46{,}656\) resamples of the six seed blocks, and the
two-sided exact sign-flip probability over all \(2^6=64\) sign assignments.
Zeros remain in both calculations. Sign-flip probabilities are unadjusted and
descriptive; they are not converted into binary discovery claims. The two
model sizes are not treated as independent replications, and repeated panels
within a seed do not increase the inferential sample size.

Mixed, null, and negative outcomes remain scientific results. A null overlap
contrast would constrain the proposal that jointly diagnostic examples alter
control at fixed marginals. A null diversity contrast would constrain the
proposal that broad semantic coverage matters beyond the number and type of
conflicts. Neither result licenses a claim about internal goals.

## Relation to the archived design

The older 120-run evidence-geometry protocol used Qwen2.5, two algorithms, ten
seeds, six geometry-by-diversity conditions, and a preceding selection gate.
It was never launched. The present study does not inherit its authorization or
epistemic status: it replaces that plan with a separate prospective Qwen3.5
study motivated by the completed contemporary-model result. The archived
configuration and protocol are preserved unchanged for provenance.
